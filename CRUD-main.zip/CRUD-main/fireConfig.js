var firebaseConfig = {
  apiKey: "AIzaSyA-T28fg3l_0DyCK_3v7u4aiquZaBjFvt4",
  authDomain: "login-c3899.firebaseapp.com",
  databaseURL: "https://login-c3899-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "login-c3899",
  storageBucket: "login-c3899.appspot.com",
  messagingSenderId: "281208810805",
  appId: "1:281208810805:web:335fb43bf82da990e8f07c",
  measurementId: "G-GTHPLTG8FT"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
